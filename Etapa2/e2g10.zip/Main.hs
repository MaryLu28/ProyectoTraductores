module Main(main) where

import Lexer
import System.Environment   
import System.Directory  
import System.IO
import Derivacion
import Parser

main :: IO ()
main = do
	[f] <- getArgs
	s <- readFile f
	print (alexScanTokens s)